%%%%%Reference total variation spatial regularization for sparse hyperspectral unmixing
function [U,iter,SRE,Res,Rel]=SUnSAL(Y,A,X_true,lambda1,lambda2,beta,miter,n1,n2)
[m,L]=size(A);
N=n1*n2;
%%%eigenvalues of AAT
[U1,S1,V1]=svd(A*A'+3*eye(size(A*A')));
Sig1=diag((1./diag(S1)));
%%%eigenvalues of  BTB=D1TD1+D2TD2+I
d1=zeros(n1,n2);
d1(end,1)=1;d1(1,1)=-1;
d2=zeros(n1,n2);
d2(1,end)=1;d2(1,1)=-1;
d1eig=fft2(d1);
d2eig=fft2(d2);
Sig2=1./((abs(d1eig)).^2+(abs(d2eig)).^2+ones(n1,n2));

%%% initialization
Lam1=zeros(L,N);
Lam2=zeros(m,N);
Lam3=zeros(m,N);
Lam4=zeros(2*m,N);
Lam5=zeros(m,N);
V1=zeros(L,N);
V2=zeros(m,N);
V3=zeros(m,N);
V4=zeros(2*m,N);
V5=zeros(m,N);
U_p=zeros(m,N);
U_p(1,1)=1;
res=1;
Res=[];
SRE=[];
Rel=[];
tol=10^(-3);
iter=0;
while res>tol && iter<miter
    %%%U subproblem
    xi1=V1+Lam1;
    xi2=V2+Lam2;
    xi3=V3+Lam3;
    xi5=V5+Lam5;
    U=U1*Sig1*U1'*(A*xi1+xi2+xi3+xi5);
    %%%V1 subproblem
    V1=(Y'+beta*(A'*U-Lam1))/(1+beta);
    %%V2 subproblem
    V2=max(abs(U-Lam2)-lambda1/beta, 0).*sign(U-Lam2);
    %%%V3 subproblem
    xi4=(V4+Lam4);
    temp=U'-Lam3'+D1T((xi4(1:m,:))',n1,n2)+D2T((xi4(m+1:2*m,:))',n1,n2);
    V3=real(calinvF(repmat(Sig2(:),1,m).*(calF(temp,n1,n2)),n1,n2));
    V3=V3';
    %%%V4 subproblem
    temp=[(D1(V3',n1,n2))';(D2(V3',n1,n2))']-Lam4;
    V4=max(abs(temp)-lambda2/beta,0).*sign(temp);
    %%%V5 subproblem
    V5=max(U-Lam5,0);
    %%% updating Lam
    Lam1=Lam1-A'*U+V1;
    Lam2=Lam2-U+V2;
    Lam3=Lam3-U+V3;
    Lam4=Lam4-[(D1(V3',n1,n2))';(D2(V3',n1,n2))']+V4;
    Lam5=Lam5-U+V5;
    %caculated relative errors for determining when to stop
    res=norm(U-U_p,'fro')/norm(U_p,'fro');
    Res=[Res,res];
    Rel=[Rel,norm(U'-X_true,'fro')/norm(X_true,'fro')];
    U_p=U;
    iter=iter+1;
    SRE=[SRE,20*log10(norm(X_true,'fro')/norm(U'-X_true,'fro'))];
end
U(U<0)=0;
    function X=calF(X,n1,n2) %%%calculate FX
        
        [N,m]=size(X);
        for ii=1:m
            temp1=fft2(reshape(X(:,ii),n1,n2));
            X(:,ii)=reshape(temp1,N,1);
        end
    end
    function X=calinvF(X,n1,n2) %%%calculate F^{*}X
        [N,m]=size(X);
        for ii=1:m
            temp2=ifft2(reshape(X(:,ii),n1,n2));
            X(:,ii)=reshape(temp2,N,1);
        end
    end
end